async function loadPredictions() {
  try {
    const response = await fetch('predictions.json');
    const data = await response.json();

    let html = "<table border='1' cellpadding='5'><tr><th>Timestamp</th><th>Open</th><th>High</th><th>Low</th><th>Close</th></tr>";
    data.predictions.forEach(c => {
      html += `<tr>
        <td>${c.timestamp}</td>
        <td>${c.open}</td>
        <td>${c.high}</td>
        <td>${c.low}</td>
        <td>${c.close}</td>
      </tr>`;
    });
    html += "</table>";

    document.getElementById("predictions").innerHTML = html;
  } catch (err) {
    document.getElementById("predictions").innerHTML = "Error loading predictions.";
  }
}

loadPredictions();
setInterval(loadPredictions, 60000);

