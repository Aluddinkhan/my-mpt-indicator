import json
from datetime import datetime, timedelta
import random

def generate_prediction():
    now = datetime.utcnow()
    predictions = []
    price = 100.0

    for i in range(2):
        candle_time = now + timedelta(minutes=i+1)
        open_price = round(price + random.uniform(-1, 1), 2)
        close_price = round(open_price + random.uniform(-1, 1), 2)
        high = max(open_price, close_price) + round(random.uniform(0, 0.5), 2)
        low = min(open_price, close_price) - round(random.uniform(0, 0.5), 2)

        predictions.append({
            "timestamp": candle_time.strftime("%Y-%m-%d %H:%M:%S"),
            "open": open_price,
            "high": round(high, 2),
            "low": round(low, 2),
            "close": close_price
        })
        price = close_price

    return predictions

if __name__ == "__main__":
    preds = generate_prediction()
    with open("predictions.json", "w") as f:
        json.dump({"predictions": preds}, f, indent=2)